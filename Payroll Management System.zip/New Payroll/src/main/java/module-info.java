module com.example.new_payroll {
    requires javafx.controls;
    requires javafx.fxml;
    requires mysql.connector.java;
    requires java.sql;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires bcrypt;

    opens com.example.new_payroll to javafx.fxml;
    exports com.example.new_payroll;
    exports com.example.new_payroll.Controller;
    opens com.example.new_payroll.Controller to javafx.fxml;
    exports com.example.new_payroll.Model;
    opens com.example.new_payroll.Model to javafx.fxml;
    //exports com.example.new_payroll;
   // opens com.example.new_payroll.Controller to javafx.fxml;
}