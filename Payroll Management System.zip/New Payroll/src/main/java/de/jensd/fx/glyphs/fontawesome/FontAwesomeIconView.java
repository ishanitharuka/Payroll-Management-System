package de.jensd.fx.glyphs.fontawesome;

public class FontAwesomeIconView {
}
