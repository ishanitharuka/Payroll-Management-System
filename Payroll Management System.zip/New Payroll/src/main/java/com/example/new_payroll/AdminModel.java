package com.example.new_payroll;

import at.favre.lib.crypto.bcrypt.BCrypt;
import com.example.new_payroll.Db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class AdminModel {
    private  Connection connection = Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;

    /*pu*//*blic AdminModel(){
        this.connection = Db.getConn();
    }*/


    public boolean login(String username, String password) {
        //boolean result = false;
        if (connection != null) {
            boolean result = false;
            String sql = "SELECT username,password FROM admin WHERE username = ? LIMIT 1";
            try {
                stmt = connection.prepareStatement(sql);
                stmt.setString(1, username);
                //stmt.setString(2,password);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    BCrypt.Result checkPwd = BCrypt.verifyer().verify(password.toCharArray(), rs.getString("password"));
                    result = checkPwd.verified;
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            return result;
        } else {
            System.out.println("Database connection is null. Check your connection initialization.");
            return false;
        }

    }

    /*public int login(){

        int validationState = INVALID_USERNAME_STATE;
        if(username !=null && password !=null){
            String query = "SELECT * FROM admin WHERE username = '"+ username +"'";
            ResultSet rs = connection.getResultFromQuery(query);

            try {

                while(rs.next()){
                    validationState = INVALID_PASSWORD_STATE;
                    String password = rs.getString("password");
                    if(password.equals(password)){
                        validationState = SUCCESSFUL_LOGIN_STATE;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


        }else{
            System.out.println("username or password is null");
        }
        return validationState;
    }*/
}
