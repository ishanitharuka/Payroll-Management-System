package com.example.new_payroll.Controller;
//import com.example.new_payroll.App;
import com.example.new_payroll.App;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class DashboardController implements Initializable{


    @FXML
    private Button btnPay;

    @FXML
    private Button btnLogOut;

    @FXML
    private Button btnPos;

    @FXML
    private Button btnRep;

    @FXML
    private Label lblUname2;

    @FXML
    private AnchorPane paneMain;

    @FXML
    void goAdmin(ActionEvent event) throws IOException {
        FXMLLoader Loader = new FXMLLoader(App.class.getResource("LoginAdmin.fxml"));
        Scene scene = new Scene(Loader.load());
        Stage dashboard = new Stage();
        dashboard.setTitle("Admin Login");
        dashboard.setScene(scene);
        dashboard.show();
        closeLoginWindow();

    }

    @FXML
    void btnEmployee(ActionEvent event) throws IOException {
        StackPane pane = new FXMLLoader().load(App.class.getResource("Employee.fxml"));
        paneMain.getChildren().setAll(pane);


    }

    @FXML
    void btnPos(ActionEvent event) throws IOException {
        StackPane pane = new FXMLLoader().load(App.class.getResource("Positions.fxml"));
        paneMain.getChildren().setAll(pane);

    }

    @FXML
    void btnPay(ActionEvent event) throws IOException {
        StackPane pane = new FXMLLoader().load(App.class.getResource("Payroll.fxml"));
        paneMain.getChildren().setAll(pane);


    }
    @FXML
    void btnRep(ActionEvent event) throws IOException {
        StackPane pane = new FXMLLoader().load(App.class.getResource("Reports.fxml"));
        paneMain.getChildren().setAll(pane);

    }

    @FXML
    public void logOut(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to logout?");
        Optional<ButtonType> option = alert.showAndWait();
        try {
            if (option.isPresent() && option.get().equals(ButtonType.OK)) {
        FXMLLoader Loader = new FXMLLoader(App.class.getResource("Login.fxml"));
        Scene scene = new Scene(Loader.load());
        Stage dashboard = new Stage();
        dashboard.setTitle("Login");
        dashboard.setScene(scene);
        dashboard.show();
        closeLoginWindow();
    }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }






    private void closeLoginWindow() {
        Stage stage = (Stage) btnLogOut.getScene().getWindow();
        stage.close();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

