package com.example.new_payroll.Controller;

import com.example.new_payroll.Db;
import com.example.new_payroll.Model.Employee;
import com.example.new_payroll.ValidationRules;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

//import static com.sun.beans.introspect.ClassInfo.clear;

public class EmployeeController implements Initializable {
    @FXML
    private Button btnSearch;

    @FXML
    private StackPane paneAddEmp;

    @FXML
    private TableColumn<Employee, String> colContact;

    @FXML
    private TableColumn<Employee, String> colFName;

    @FXML
    private TableColumn<Employee, String> colGen;

    @FXML
    private TableColumn<Employee, Integer> colID;

    @FXML
    private TableColumn<Employee, String> colLName;

    @FXML
    private TableColumn<Employee, String> colPos;

    @FXML
    private TableView<Employee> table;

    @FXML
    private TextField txtSearch;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnInsert;

    @FXML
    private ComboBox<?> cmbGen;

    @FXML
    private ComboBox<?> cmbPos;

    @FXML
    private TextField txtCon;

    @FXML
    private TextField txtEmpID;

    @FXML
    private TextField txtFName;

    @FXML
    private TextField txtLName;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        viewEmployee();

        genderList();
        positionList();


    }
    private String[] genderList = {"Male", "Female"};
    public void genderList(){
        List<String> listG = new ArrayList<>();

        for(String data: genderList){
            listG.add(data);
        }
        ObservableList listData = FXCollections.observableArrayList(listG);
        cmbGen.setItems(listData);
    }

    /*public void genderList(){
        String sql = "SELECT * FROM `employee` WHERE `Emp_ID` ='" + txtEmpID.getSelection().getSelectedItem()+"'";
        connection = Db.getConn();
        try{
            ObservableList listData = FXCollections.observableArrayList();
            stat = connection.prepareStatement(sql);
            rs = stat.executeQuery();

            while(rs.next()){
                listData.add(rs.getString("Gender"));
            }
            cmbGen.set
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }*/
    private String[] positionList = {"Machine Operator", "Team Leader", "Supervisor", "Executive"};
    public void positionList(){
        List<String> listP = new ArrayList<>();

        for(String data: positionList){
            listP.add(data);
        }
        ObservableList listData = FXCollections.observableArrayList(listP);
        cmbPos.setItems(listData);
    }





    private static Connection connection = Db.getConn();
    private PreparedStatement stat;
    private ResultSet rs;



    public ObservableList<Employee> getEmployee(){
        ObservableList<Employee> employees = FXCollections.observableArrayList();

        String query = "SELECT * FROM `employee`";
        connection = Db.getConn();
        try{
            stat = connection.prepareStatement(query);
            rs = stat.executeQuery();
            while (rs.next()){
                Employee stat = new Employee();
                stat.setEmp_ID(rs.getInt("Emp_ID"));
                stat.setFirst_Name(rs.getString("First_Name"));
                stat.setLast_Name(rs.getString("Last_Name"));
                stat.setGender(rs.getString("Gender"));
                stat.setContact_No(rs.getString("Contact_No"));
                stat.setPosition(rs.getString("Position"));
                employees.add(stat);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return employees;
    }

    public void viewEmployee(){
        ObservableList<Employee> list = getEmployee();
        table.setItems(list);
        colID.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("Emp_ID"));
        colFName.setCellValueFactory(new PropertyValueFactory<Employee, String>("First_Name"));
        colLName.setCellValueFactory(new PropertyValueFactory<Employee, String>("Last_Name"));
        colGen.setCellValueFactory(new PropertyValueFactory<Employee, String>("Gender"));
        colContact.setCellValueFactory(new PropertyValueFactory<Employee, String>("Contact_No"));
        colPos.setCellValueFactory(new PropertyValueFactory<Employee, String>("Position"));

    }

    public void clearFields(ActionEvent event){
        clear();
    }

    public void AddEmployee(ActionEvent event) {
        String insert = "INSERT INTO `employee`(`First_Name`, `Last_Name`, `Gender`, `Contact_No`, `Position`) VALUES (?,?,?,?,?)";
        connection = Db.getConn();
        if (ValidationRules.isEmpty(txtFName.getText()) || ValidationRules.isEmpty(txtLName.getText()) || ValidationRules.isEmpty(txtEmpID.getText()) || ValidationRules.isEmpty(txtCon.getText()) || ValidationRules.isEmpty((String) cmbGen.getSelectionModel().getSelectedItem()) || ValidationRules.isEmpty((String) cmbPos.getSelectionModel().getSelectedItem())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "All Fields are Required !!", ButtonType.OK);
            alert.show();
        } else if(ValidationRules.isText(txtEmpID.getText()) || ValidationRules.isText(txtCon.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else if (!ValidationRules.isMobile(txtCon.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        } else if (!ValidationRules.isText(txtFName.getText()) || (!ValidationRules.isText(txtLName.getText()))) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else{
        try {
                stat = connection.prepareStatement(insert);
                //stat.setInt(1, txtEmpID.getText());
                stat.setString(1, txtFName.getText());
                stat.setString(2, txtLName.getText());
                stat.setString(3, (String) cmbGen.getSelectionModel().getSelectedItem());
                stat.setString(4, txtCon.getText());
                stat.setString(5, (String) cmbPos.getSelectionModel().getSelectedItem());
                stat.executeUpdate();
                viewEmployee();
                clear();


            } catch (SQLException e) {
                throw new RuntimeException(e);
            }


        }
    }

    public void clear(){

        txtEmpID.setText("");
        txtFName.setText("");
        txtLName.setText("");
        cmbGen.getSelectionModel().clearSelection();
        txtCon.setText("");
        cmbPos.getSelectionModel().clearSelection();
    }
    @FXML
    void getData(MouseEvent event) {
        Employee employee = table.getSelectionModel().getSelectedItem();
        txtEmpID.setText(String.valueOf(employee.getEmp_ID()));
        txtFName.setText(employee.getFirst_Name());
        txtLName.setText(employee.getLast_Name());
        //cmbGen.setValue(employee.getGender());
        txtCon.setText(employee.getContact_No());
        //cmbPos.setValue(employee.getPosition());


    }

    public void checkID(){
        String checkQuery = "SELECT `Emp_ID` FROM `employee` WHERE `Emp_ID` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(checkQuery);
            stat.setString(1, txtEmpID.getText());
            rs = stat.executeQuery();

            if (rs.next()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Emp_ID already exists!", ButtonType.OK);
                alert.showAndWait();
                txtEmpID.setText("");
            }
            rs.close();
            stat.close();


        } catch (Exception e) {
            throw new RuntimeException(e);
        }











        /*String check = "SELECT `Emp_ID` FROM `employee` WHERE `Emp_ID` = ?";
        connection = Db.getConn();
        int check1 = Integer.parseInt(check);
        try{
            if(check1>0){
                Alert alert = new Alert(Alert.AlertType.WARNING, "Emp_ID already Exist !!", ButtonType.OK);
                alert.show();
        }

    } catch (Exception e) {
            throw new RuntimeException(e);
        }*/}



        public void UpdateEmployee(ActionEvent event) {
        String update = "UPDATE `employee` SET `First_Name`= ?,`Last_Name`= ?,`Gender`= ?,`Contact_No`= ?,`Position`= ? WHERE `Emp_ID`= ?";
        connection = Db.getConn();
        if (ValidationRules.isEmpty(txtFName.getText()) || ValidationRules.isEmpty(txtLName.getText()) || ValidationRules.isEmpty(txtEmpID.getText()) || ValidationRules.isEmpty(txtCon.getText()) || ValidationRules.isEmpty((String) cmbGen.getSelectionModel().getSelectedItem()) || ValidationRules.isEmpty((String) cmbPos.getSelectionModel().getSelectedItem())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "All Fields are Required !!", ButtonType.OK);
            alert.show();
        } else if(ValidationRules.isText(txtEmpID.getText()) || ValidationRules.isText(txtCon.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else if (!ValidationRules.isMobile(txtCon.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        } else if (!ValidationRules.isText(txtFName.getText()) || (!ValidationRules.isText(txtLName.getText()))) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else{
            try {
                stat = connection.prepareStatement(update);


                stat.setString(1, txtFName.getText());
                stat.setString(2, txtLName.getText());
                stat.setString(3, (String) cmbGen.getSelectionModel().getSelectedItem());
                stat.setString(4, txtCon.getText());
                stat.setString(5, (String) cmbPos.getSelectionModel().getSelectedItem());
                stat.setString(6, txtEmpID.getText());
                stat.executeUpdate();
                viewEmployee();
                clear();

            } catch (SQLException e) {
                throw new RuntimeException(e);

            }


        }
    }



    public void delEmployee(ActionEvent event){
        String delete = "DELETE FROM `employee` WHERE `Emp_ID` = ?";
        connection = Db.getConn();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to delete?");
        Optional<ButtonType> option = alert.showAndWait();
        try {
            if (option.isPresent() && option.get().equals(ButtonType.OK)) {
        try{
            stat = connection.prepareStatement(delete);
            stat.setString(1, txtEmpID.getText());
            stat.executeUpdate();
            viewEmployee();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        }} catch (Exception e) {
            e.printStackTrace();
        }
    }}




