package com.example.new_payroll;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class App extends Application{
        @Override
        public void start(Stage stage) throws IOException {
            FXMLLoader Loader = new FXMLLoader(App.class.getResource("Login.fxml"));
            Scene scene = new Scene(Loader.load());
            Stage dashboard = new Stage();
            dashboard.setTitle("Login");
            dashboard.setScene(scene);
            dashboard.show();

        }

        public static void main(String[] args) {
            launch();
        }
    }

