package com.example.new_payroll.Controller;

import com.example.new_payroll.Db;
import com.example.new_payroll.Model.Employee;
import com.example.new_payroll.Model.Position;
import com.example.new_payroll.ValidationRules;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Optional;
import java.util.ResourceBundle;

public class PositionController implements Initializable {
    @FXML
    private TableColumn<Position, Integer> colAtt;

    @FXML
    private TableColumn<Position, Float> colBasic;

    @FXML
    private TableColumn<Position, Float> colEPF;

    @FXML
    private TableColumn<Position, Integer> colIncen;

    @FXML
    private TableColumn<Position, String> colName;

    @FXML
    private TableColumn<Position, Float> colOT;


    @FXML
    private TableView<Position> tablePos;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnDlt;

    @FXML
    private Button btnInsert;

    @FXML
    private Button btnSearch;

    @FXML
    private Button btnUpdate;

    @FXML
    private TextField txtAtt;

    @FXML
    private TextField txtBasic;

    @FXML
    private TextField txtEPF;

    @FXML
    private TextField txtIncen;

    @FXML
    private TextField txtOT;

    @FXML
    private TextField txtPos;

    @FXML
    private TextField txtSearch;
    private ObservableList<Position> list;
    private InvalidationListener Observable;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        viewPosition();

    }

    @FXML
    public void autoEPF(KeyEvent event) {
        double basic = Double.parseDouble(txtBasic.getText());
        double EPF, OT;

        EPF = basic * 0.08;
        OT = basic /160;

        txtEPF.setText(String.valueOf(decimal(EPF)));
        txtOT.setText(String.valueOf(decimal(OT)));

    }

    public static String decimal(double value) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        return decimalFormat.format(value);
    }



    private static Connection connection = Db.getConn();
    private PreparedStatement stat;
    private ResultSet rs;

    public ObservableList<Position> getPosition(){
        ObservableList<Position> positions = FXCollections.observableArrayList();

        String query = "SELECT * FROM `positions`";
        connection = Db.getConn();
        try{
            stat = connection.prepareStatement(query);
            rs = stat.executeQuery();
            while (rs.next()){
                Position stat = new Position();
                stat.setName(rs.getString("Name"));
                stat.setBasic(rs.getFloat("Basic"));
                stat.setEPF(rs.getFloat("EPF"));
                stat.setOT(rs.getFloat("OT"));
                stat.setAttendance(rs.getInt("Attendance"));
                stat.setIncentive(rs.getInt("Incentive"));
                positions.add(stat);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return positions;
    }


    /*private ObservableList<Position> positionData = getPosition();
    public void positionDataList(){
        positionData = PositionData();
        tablePos.setItems(positionData);
        colName.setCellValueFactory(new PropertyValueFactory<Position, String>("Name"));
        colBasic.setCellValueFactory(new PropertyValueFactory<Position, Float>("Basic"));
        colEPF.setCellValueFactory(new PropertyValueFactory<Position, Float>("EPF"));
        colOT.setCellValueFactory(new PropertyValueFactory<Position, Float>("OT"));
        colAtt.setCellValueFactory(new PropertyValueFactory<Position, Integer>("Attendance"));
        colIncen.setCellValueFactory(new PropertyValueFactory<Position, Integer>("Incentive"));
    }*/

    /*private ObservableList<Position> PositionData() {
        return null;
    }*/


    public void viewPosition(){
        ObservableList<Position> list = getPosition();
        tablePos.setItems(list);
        colName.setCellValueFactory(new PropertyValueFactory<Position, String>("Name"));
        colBasic.setCellValueFactory(new PropertyValueFactory<Position, Float>("Basic"));
        colEPF.setCellValueFactory(new PropertyValueFactory<Position, Float>("EPF"));
        colOT.setCellValueFactory(new PropertyValueFactory<Position, Float>("OT"));
        colAtt.setCellValueFactory(new PropertyValueFactory<Position, Integer>("Attendance"));
        colIncen.setCellValueFactory(new PropertyValueFactory<Position, Integer>("Incentive"));

    }

    /*public void PositionSearch(){

        FilteredList<Position> filter = new FilteredList<>(list, e-> true);
        txtSearch.textProperty().addListener(Observable, oldValue, newValue) -> {
            filter.setPredicate(predicatePosition->{
                if(newValue == null || newValue.isEmpty()){
                    
                }
            });
        });
    }*/

    public void clearFields(ActionEvent event){
        clear();
    }

    public void AddPosition(ActionEvent event){
        String insert = "INSERT INTO `positions`(`Name`, `Basic`, `EPF`, `OT`, `Attendance`, `Incentive`) VALUES (?,?,?,?,?,?)";
        connection = Db.getConn();
        if (ValidationRules.isEmpty(txtPos.getText()) || ValidationRules.isEmpty(txtBasic.getText()) || ValidationRules.isEmpty(txtEPF.getText()) || ValidationRules.isEmpty(txtOT.getText()) || ValidationRules.isEmpty(txtAtt.getText()) || ValidationRules.isEmpty(txtIncen.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "All Fields are Required !!", ButtonType.OK);
            alert.show();
        } else if(ValidationRules.isText(txtBasic.getText()) || ValidationRules.isText(txtOT.getText()) || ValidationRules.isText(txtIncen.getText()) || ValidationRules.isText(txtEPF.getText()) || ValidationRules.isText(txtAtt.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else{
        try{
            stat = connection.prepareStatement(insert);
            //stat.setInt(1, txtEmpID.getText());
            stat.setString(1, txtPos.getText());
            stat.setFloat(2, Float.parseFloat(txtBasic.getText()));
            stat.setFloat(3, Float.parseFloat(txtEPF.getText()));
            stat.setFloat(4, Float.parseFloat(txtOT.getText()));
            stat.setInt(5, Integer.parseInt(txtAtt.getText()));
            stat.setInt(6, Integer.parseInt(txtIncen.getText()));
            stat.executeUpdate();
            viewPosition();
            clear();



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }}



    void clear(){

        txtPos.setText("");
        txtBasic.setText("");
        txtEPF.setText("");
        txtOT.setText("");
        txtAtt.setText("");
        txtIncen.setText("");

    }
    @FXML
    void getData(MouseEvent event) {
        Position position = tablePos.getSelectionModel().getSelectedItem();
        txtPos.setText(position.getName());
        txtBasic.setText(String.valueOf(position.getBasic()));
        txtEPF.setText(String.valueOf(position.getEPF()));
        txtOT.setText(String.valueOf(position.getOT()));
        txtAtt.setText(String.valueOf(position.getAttendance()));
        txtIncen.setText(String.valueOf(position.getIncentive()));

    }

    public void checkPos(){
        String checkQuery = "SELECT `Name` FROM `positions` WHERE `Name` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(checkQuery);
            stat.setString(1, txtPos.getText());
            rs = stat.executeQuery();

            if (rs.next()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Position Name already exists!", ButtonType.OK);
                alert.showAndWait();
                txtPos.setText("");
            }
            rs.close();
            stat.close();


        } catch (Exception e) {
            throw new RuntimeException(e);
        }}

    public void UpdatePosition(ActionEvent event){
        String update = "UPDATE `positions` SET `Basic`=?,`EPF`=?,`OT`=?,`Attendance`=?,`Incentive`=? WHERE `Name`=?";
        connection = Db.getConn();
        if (ValidationRules.isEmpty(txtPos.getText()) || ValidationRules.isEmpty(txtBasic.getText()) || ValidationRules.isEmpty(txtEPF.getText()) || ValidationRules.isEmpty(txtOT.getText()) || ValidationRules.isEmpty(txtAtt.getText()) || ValidationRules.isEmpty(txtIncen.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "All Fields are Required !!", ButtonType.OK);
            alert.show();
        } else if(ValidationRules.isText(txtBasic.getText()) || ValidationRules.isText(txtOT.getText()) || ValidationRules.isText(txtIncen.getText()) || ValidationRules.isText(txtEPF.getText()) || ValidationRules.isText(txtAtt.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else{
        try{
            stat = connection.prepareStatement(update);



            stat.setFloat(1, Float.parseFloat(txtBasic.getText()));
            stat.setFloat(2, Float.parseFloat(txtEPF.getText()));
            stat.setFloat(3, Float.parseFloat(txtOT.getText()));
            stat.setInt(4, Integer.parseInt(txtAtt.getText()));
            stat.setInt(5, Integer.parseInt(txtIncen.getText()));
            stat.setString(6, txtPos.getText());

            stat.executeUpdate();
            viewPosition();
            clear();

        } catch (SQLException e) {
            throw new RuntimeException(e);

        }


    }}



    public void delPosition(ActionEvent event){
        String delete = "DELETE FROM `positions` WHERE `Name` = ?";
        connection = Db.getConn();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to delete?");
        Optional<ButtonType> option = alert.showAndWait();
        try {
            if (option.isPresent() && option.get().equals(ButtonType.OK)) {
        try{
            stat = connection.prepareStatement(delete);
            stat.setString(1, txtPos.getText());
            stat.executeUpdate();
            viewPosition();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }} catch (Exception e) {
            e.printStackTrace();
        }

}}
