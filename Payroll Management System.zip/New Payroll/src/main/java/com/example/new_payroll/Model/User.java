/*
package com.example.new_payroll.Model;

public class User {
    public static final int INVALID_USERNAME_STATE = 1;
    public static final int INVALID_PASSWORD_STATE = 2;
    public static final int SUCCESSFUL_LOGIN_STATE = 3;

    private static User currentUser;
    private String userId;
    private String passWordHash;

    public static int loginUser(String username, String password){
        currentUser = new User(username,password);
        return currentUser.validateUser();
    }





}
*/
