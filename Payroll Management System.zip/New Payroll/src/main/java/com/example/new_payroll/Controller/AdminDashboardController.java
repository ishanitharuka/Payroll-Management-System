package com.example.new_payroll.Controller;

import com.example.new_payroll.App;
import com.example.new_payroll.Db;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class AdminDashboardController implements Initializable {


    private static Connection connection = Db.getConn();
    private PreparedStatement stat;
    private ResultSet rs;
    @FXML
    private Button btnAdmin;

    @FXML
    private Button btnLogOut;

    @FXML
    private Button btnReg;

    @FXML
    private Label lblUname2;

    @FXML
    private AnchorPane paneMain;

    @FXML
    private TextField txtPwd;

    @FXML
    private TextField txtUname;

    @FXML
    void goUser(ActionEvent event) throws IOException {
        FXMLLoader Loader = new FXMLLoader(App.class.getResource("Dashboard.fxml"));
        Scene scene = new Scene(Loader.load());
        Stage dashboard = new Stage();
        dashboard.setTitle("Dashboard");
        dashboard.setScene(scene);
        dashboard.show();
        closeLoginWindow();
    }

    @FXML
    void logOut(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure you want to logout?");
        Optional<ButtonType> option = alert.showAndWait();
        try {
            if (option.isPresent() && option.get().equals(ButtonType.OK)) {
                FXMLLoader Loader = new FXMLLoader(App.class.getResource("Login.fxml"));
                Scene scene = new Scene(Loader.load());
                Stage dashboard = new Stage();
                dashboard.setTitle("Login");
                dashboard.setScene(scene);
                dashboard.show();
                closeLoginWindow();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*public void checkID() {
        String checkQuery = "SELECT `name` FROM `user` WHERE `name` = ?";

        try (Connection connection = Db.getConn();
             PreparedStatement stat = connection.prepareStatement(checkQuery)) {

            stat.setString(1, txtUname.getText());
            try (ResultSet rs = stat.executeQuery()) {
                if (rs.next()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "Username already exists!", ButtonType.OK);
                    alert.show();
                }
            }

        } catch (Exception e) {
            // Handle the exception appropriately (print or log details)
            throw new RuntimeException(e);
        }
    }*/


    private void closeLoginWindow() {
        Stage stage = (Stage) btnLogOut.getScene().getWindow();
        stage.close();
    }

    @FXML
    void regUser(ActionEvent event) {
        String insert = "INSERT INTO `user`(`name`, `password`) VALUES ( ?, ?);";
        connection = Db.getConn();
        try{
            stat = connection.prepareStatement(insert);
            //checkID();
            stat.setString(1, txtUname.getText());
            stat.setString(2, txtPwd.getText());
            stat.executeUpdate();
            txtUname.setText("");
            txtPwd.setText("");
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Successfully Registered", ButtonType.OK);
            alert.show();



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public void checkID() {
        String checkQuery = "SELECT `name` FROM `user` WHERE `name` = ?";

        try (Connection connection = Db.getConn();
             PreparedStatement stat = connection.prepareStatement(checkQuery)) {

            stat.setString(1, txtUname.getText());
            try (ResultSet rs = stat.executeQuery()) {
                if (rs.next()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "Username already exists!", ButtonType.OK);
                    alert.show();
                }
            }

        } catch (Exception e) {
            // Handle the exception appropriately (print or log details)
            throw new RuntimeException(e);
        }
    }




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
