/*package com.example.new_payroll.Model;

import com.almasb.fxgl.core.View;
import com.example.new_payroll.Db;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class View_Employee {
    private Connection conn = Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;
    public static ObservableList<View> getUser(){
        Connection Conn = Db.getConn();
        ObservableList<View> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM employee";
        try {
            PreparedStatement stmt;
            stmt = Conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                String Emp_ID = rs.getString("Emp_ID");
                String First_Name = rs.getString("First_Name");
                String Last_Name = rs.getString("Last_Name");
                String Gender = rs.getString("Gender");
                String Contact_No = rs.getString("Contact_No");
                String Position_ID = rs.getString("Position_ID");

                list.add(new View(Emp_ID, First_Name, Last_Name, Gender, Contact_No, Position_ID) {


                });
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return list;
    }
}*/
