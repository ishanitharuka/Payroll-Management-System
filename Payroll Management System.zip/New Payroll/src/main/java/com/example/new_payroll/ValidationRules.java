package com.example.new_payroll;

public class ValidationRules {
    public static boolean isEmpty(String val) {
        return (val == null || val.isEmpty() || val.isBlank());
    }


    public static boolean isMobile(String phone) {
        isEmpty(phone);
        return phone.matches("\\d{10}") && phone.length() == 10;
    }

    public static boolean isText(String val) {
        isEmpty(val);
        return val.matches("[a-zA-Z ]+");
    }



}