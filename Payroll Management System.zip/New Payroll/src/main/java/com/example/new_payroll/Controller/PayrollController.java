package com.example.new_payroll.Controller;

import com.example.new_payroll.App;
import com.example.new_payroll.Db;
import com.example.new_payroll.Model.Employee;
import com.example.new_payroll.ValidationRules;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class PayrollController implements Initializable {

    private static Connection connection = Db.getConn();
    private PreparedStatement stat;
    private ResultSet rs;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnprint;

    @FXML
    private CheckBox cBoxAtt;

    @FXML
    private CheckBox cBoxIncen;

    @FXML
    private CheckBox cBoxAdd;

    @FXML
    private TextField txtBasic;

    @FXML
    private TextField txtTotalSalary;

    @FXML
    private TextField txtEPF;

    @FXML
    private TextField txtNoPayDays;

    @FXML
    private TextField txtNoPayDed;

    @FXML
    private TextField txtETF;

    @FXML
    private TextField txtEmpID;

    @FXML
    private TextField txtLeaves;

    @FXML
    private TextField txtOTHours;

    @FXML
    private TextField txtOTRate;

    @FXML
    private TextField txtPos;

    @FXML
    private TextField txtPruning;

    @FXML
    private TextField txtTotalOT;

    @FXML
    private TextField txtAtt;

    @FXML
    private TextField txtIncen;

    private TextField txtTax;

    @FXML
    private Label lbl;

    @FXML
    private Label lblAtt;

    @FXML
    private Label lblBasic;

    @FXML
    private Label lblCon;

    @FXML
    private Label lblEPF;

    @FXML
    private Label lblEmp_ID;

    @FXML
    private Label lblIncen;

    @FXML
    private Label lblLeave;

    @FXML
    private Label lblName;

    @FXML
    private Label lblNetSal;

    @FXML
    private Label lblOT;

    @FXML
    private Label lblPos;

    @FXML
    private Label lblTax;

    @FXML
    private Label lblTotDed;

    @FXML
    private Label lblTotEarn;

    @FXML
    private Label lblNetPay;

    @FXML
    private AnchorPane panePaySheet;




    @FXML
    public void retreive(KeyEvent event) {
        getPosition();
        getValue();



    }

    @FXML
    void close(ActionEvent event) {
        panePaySheet.setVisible(false);
        clearFields();


    }

    public void checkPos(){
        String checkQuery = "SELECT `Name` FROM `positions` WHERE `Name` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(checkQuery);
            stat.setString(1, txtPos.getText());
            rs = stat.executeQuery();

            if (!rs.next()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Position Name !", ButtonType.OK);
                alert.showAndWait();
                txtPos.setText("");
            }
            rs.close();
            stat.close();


        } catch (Exception e) {
            throw new RuntimeException(e);
        }}

    public void checkID(){
        String checkQuery = "SELECT `Emp_ID` FROM `employee` WHERE `Emp_ID` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(checkQuery);
            stat.setString(1, txtEmpID.getText());
            rs = stat.executeQuery();

            if (!rs.next()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Emp_ID !", ButtonType.OK);
                alert.showAndWait();
                clearFields();
            }
            rs.close();
            stat.close();


        } catch (Exception e) {
            throw new RuntimeException(e);
        }}

    public void getTotal() {
        double total, basic, EPF, OT, Att, Incen, noPay;

        if (ValidationRules.isText(txtEmpID.getText()) || !ValidationRules.isText(txtPos.getText()) ||
                ValidationRules.isText(String.valueOf(txtBasic.getText())) || ValidationRules.isText(String.valueOf(txtTotalOT.getText())) ||
                ValidationRules.isText(String.valueOf(txtIncen.getText())) || ValidationRules.isText(String.valueOf(txtAtt.getText())) ||
                ValidationRules.isText(String.valueOf(txtEPF.getText())) || ValidationRules.isText(String.valueOf(txtNoPayDays.getText())) ||
                ValidationRules.isText(String.valueOf(txtOTRate.getText())) || ValidationRules.isText(String.valueOf(txtNoPayDed.getText())) ||
                ValidationRules.isText(txtOTHours.getText())) {

            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();

        } else if (ValidationRules.isEmpty(txtEmpID.getText()) || ValidationRules.isEmpty(txtPos.getText()) ||
                ValidationRules.isEmpty(String.valueOf(txtBasic.getText())) || ValidationRules.isEmpty(String.valueOf(txtEPF.getText())) ||
                ValidationRules.isEmpty(String.valueOf(txtOTRate.getText()))) {

            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();

        } else if (ValidationRules.isEmpty(txtOTHours.getText()) || ValidationRules.isEmpty(txtTotalOT.getText())) {
            txtOTHours.setText(String.valueOf(0));
            txtTotalOT.setText(String.valueOf(0.0));
        } else if (ValidationRules.isEmpty(txtNoPayDays.getText()) || ValidationRules.isEmpty(txtNoPayDed.getText())) {
            txtNoPayDays.setText(String.valueOf(0));
            txtNoPayDed.setText(String.valueOf(0.0));
        } else if (ValidationRules.isEmpty(txtAtt.getText())) {
            txtAtt.setText(String.valueOf(0.0));
        } else if (ValidationRules.isEmpty(txtIncen.getText())) {
            txtIncen.setText(String.valueOf(0.0));
        } else {
            try {
                basic = Double.parseDouble(txtBasic.getText());
                OT = Double.parseDouble(txtTotalOT.getText());
                Att = Double.parseDouble(txtAtt.getText());
                Incen = Double.parseDouble(txtIncen.getText());
                EPF = Double.parseDouble(txtEPF.getText());
                noPay = Double.parseDouble(txtNoPayDed.getText());

                checkID();
                checkPos();

                total = basic + OT + Att + Incen - EPF - noPay;

                txtTotalSalary.setText(String.format("%.2f", total));

            } catch (NumberFormatException e) {
                // Handle the case where parsing fails
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid numeric input!", ButtonType.OK);
                alert.showAndWait();
            }
        }
    }


    public void calTotal(){
        getTotal();
    }



    public void assignEmp(){
        int emp_ID = Integer.parseInt(txtEmpID.getText());
        String position = txtPos.getText();
        double basic = Double.parseDouble(txtBasic.getText());
        double OT = Double.parseDouble(txtTotalOT.getText());
        double Incen = Double.parseDouble(txtIncen.getText());
        double Att = Double.parseDouble(txtAtt.getText());
        double EPF = Double.parseDouble(txtEPF.getText());
        double noPay = Double.parseDouble(txtNoPayDed.getText());
        double crntTotal = Double.parseDouble(txtTotalSalary.getText());

        if (ValidationRules.isEmpty(txtEmpID.getText()) || ValidationRules.isEmpty(txtPos.getText()) || ValidationRules.isEmpty(txtOTHours.getText()) || ValidationRules.isEmpty(txtTotalOT.getText()) || ValidationRules.isEmpty(txtNoPayDays.getText()) || ValidationRules.isEmpty(txtOTRate.getText()) || ValidationRules.isEmpty(txtNoPayDed.getText()) || ValidationRules.isEmpty(txtAtt.getText()) || ValidationRules.isEmpty(txtIncen.getText()) || ValidationRules.isEmpty(txtEPF.getText()) || ValidationRules.isEmpty(txtBasic.getText()) ||ValidationRules.isEmpty(txtTotalSalary.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "All Fields are Required !!", ButtonType.OK);
            alert.show();
        } else if (ValidationRules.isText(txtEmpID.getText()) || !ValidationRules.isText(position) || ValidationRules.isText(String.valueOf(basic)) || ValidationRules.isText(String.valueOf(OT)) || ValidationRules.isText(String.valueOf(Incen)) || ValidationRules.isText(String.valueOf(Att)) || ValidationRules.isText(String.valueOf(EPF)) || ValidationRules.isText(String.valueOf(basic)) || ValidationRules.isText(String.valueOf(noPay)) || ValidationRules.isText(String.valueOf(crntTotal)) || ValidationRules.isText(String.valueOf(txtOTRate.getText())) || ValidationRules.isText(txtNoPayDays.getText())) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Input !!", ButtonType.OK);
            alert.show();
        }else{


        double tax = 0;
        if(crntTotal >= 100000 && crntTotal < 141667){
            tax = crntTotal * 0.06;
        } else if (crntTotal >= 141667 && crntTotal < 183333) {
            tax = crntTotal * 0.12;
        } else if (crntTotal >= 183333 && crntTotal < 225000) {
            tax = crntTotal * 0.18;
        } else if (crntTotal >= 225000 && crntTotal < 266667) {
            tax = crntTotal * 0.24;
        } else if (crntTotal >= 266667 && crntTotal < 308333) {
            tax = crntTotal * 0.3;
        } else if (crntTotal >= 308333) {
            tax = crntTotal * 0.36;
        }else {
            tax = 0;
        }




        double totalEarning = basic + OT + Incen + Att;
        double totalDeduction = EPF + noPay + tax;
        double netPay = totalEarning - totalDeduction;


            lblEmp_ID.setText(String.valueOf(emp_ID));
        lblPos.setText(position);
        lblBasic.setText(String.valueOf(PositionController.decimal(basic)));
        lblOT.setText(String.valueOf(PositionController.decimal(OT)));
        lblIncen.setText(String.valueOf(PositionController.decimal(Incen)));
        lblAtt.setText(String.valueOf(PositionController.decimal(Att)));
        lblEPF.setText(String.valueOf(PositionController.decimal(EPF)));
        lblLeave.setText(String.valueOf(PositionController.decimal(noPay)));
        lblTax.setText(String.valueOf(PositionController.decimal(tax)));
        lblTotEarn.setText(String.valueOf(PositionController.decimal(totalEarning)));
        lblTotDed.setText(String.valueOf(PositionController.decimal(totalDeduction)));
        lblNetSal.setText(String.valueOf(PositionController.decimal(netPay)));
        lblNetPay.setText(String.valueOf(PositionController.decimal(netPay)));


        String empId = txtEmpID.getText();
        String query = "SELECT `First_Name`, `Last_Name`,`Contact_No` FROM `employee` WHERE `Emp_ID` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(query);
            stat.setString(1, empId);
            rs = stat.executeQuery();
            if (rs.next()) {
                String firstname = rs.getString("First_Name");
                String lastname = rs.getString("Last_Name");
                String contact = rs.getString("Contact_No");
                lblCon.setText(contact);

                lblName.setText(firstname + " " + lastname);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }}

    //PositionController position = new PositionController();

    @FXML
    void clearFields() {
        txtEmpID.setText("");
        txtPos.setText("");
        txtBasic.setText("");
        txtEPF.setText("");
        txtIncen.setText("");
        txtAtt.setText("");
        txtNoPayDed.setText("");
        txtTotalSalary.setText("");
        txtTotalOT.setText("");
        txtOTRate.setText("");
        txtNoPayDays.setText("");
        txtOTHours.setText("");
        cBoxAtt.setSelected(false);
        cBoxIncen.setSelected(false);


    }

    @FXML
    public void mvPay(ActionEvent event) throws IOException {

        assignEmp();
        panePaySheet.setVisible(true);





    }
    private void closeLoginWindow() {
        Stage stage = (Stage) btnprint.getScene().getWindow();
        stage.close();
    }



        /*try {
            if (ValidationRules.isEmpty(String.valueOf(basic)) || ValidationRules.isEmpty(String.valueOf(EPF))) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Some Fields are Required !!", ButtonType.OK);
                alert.show();
            }else{

            }*/








        /*if(OT = null){
            OT = 0;
        }

        total = basic + OT + Att + Incen - EPF - noPay;

        txtTotalSalary.setText(String.valueOf(total));

    }*/

    /*public void calTotal() {
        double total;
        double basic, OT, Att, Incen, EPF, noPay;

        try {
            if (!txtBasic.getText().isEmpty()) {
                basic = Double.parseDouble(txtBasic.getText());
            } else {
                basic = 0.0; // Set a default value or handle it according to your requirements
            }
            basic = Double.parseDouble(txtBasic.getText());
            OT = Double.parseDouble(txtTotalOT.getText());
            Att = Double.parseDouble(txtAtt.getText());
            Incen = Double.parseDouble(txtIncen.getText());
            EPF = Double.parseDouble(txtEPF.getText());
            noPay = Double.parseDouble(txtNoPayDed.getText());


            total = basic + OT + Att + Incen - EPF - noPay;
            txtTotalSalary.setText(String.valueOf(total));
        } catch (NumberFormatException e) {
            // Handle the case where the input is not a valid double
            // For example, show an error message or set default values
            txtTotalSalary.setText("Invalid Input");
        }
    }*/


    @FXML
    void noPay(KeyEvent event) {
        double noPayDays = Double.parseDouble(txtNoPayDays.getText());
        double basic = Double.parseDouble(txtBasic.getText());
        double noPayRate = basic/30;
        double noPayDed = noPayDays * noPayRate;
        txtNoPayDed.setText(String.valueOf(PositionController.decimal(noPayDed)));

    }



    public void getPosition() {
        String empId = txtEmpID.getText();

        String query = "SELECT `Position` FROM `employee` WHERE `Emp_ID` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(query);
            stat.setString(1, empId);
            rs = stat.executeQuery();
            if (rs.next()) {
                String position = rs.getString("Position");
                txtPos.setText(position);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void getValue() {
        String position = txtPos.getText();


        String query = "SELECT `Basic`, `EPF`, `OT` FROM `positions` WHERE `Name` = ?";
        connection = Db.getConn();

        try {
            stat = connection.prepareStatement(query);
            stat.setString(1, position);

            rs = stat.executeQuery();
            if (rs.next()) {
                String basic = rs.getString("Basic");
                String EPF = rs.getString("EPF");
                String OT = rs.getString("OT");
                txtBasic.setText(basic);
                txtEPF.setText(EPF);
                txtOTRate.setText(OT);
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void calOT(KeyEvent event) {
        double OTRate = Double.parseDouble(txtOTRate.getText());
        double OTHours = Double.parseDouble(txtOTHours.getText());
        double TotalOT;

        TotalOT = OTRate * OTHours;
        txtTotalOT.setText(String.valueOf(TotalOT));

    }

    @FXML
    public void handleAtt(ActionEvent event) {
        String position = txtPos.getText();
        String query = "SELECT `Attendance` FROM `positions` WHERE `Name`= ?";
        connection = Db.getConn();
        try {
            stat = connection.prepareStatement(query);
            stat.setString(1, position);
            rs = stat.executeQuery();
            if (rs.next()) {
                double att = rs.getDouble("Attendance");
                txtAtt.setText(String.valueOf(att));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        double Att;
        if(cBoxAtt.isSelected()){
            double att = Double.parseDouble(txtAtt.getText());
            Att = att;
            txtAtt.setText(String.valueOf(Att));
        }
        if(!cBoxAtt.isSelected()){
            txtAtt.clear();
        }


    }

    /*@FXML
    void addSalary(ActionEvent event) {
        if (cBoxAdd.isSelected()) {
            if (ValidationRules.isEmpty(txtBasic.getText()) || ValidationRules.isEmpty(txtPos.getText()) || ValidationRules.isEmpty(txtEPF.getText()) || ValidationRules.isEmpty(txtEmpID.getText())) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Enter Username and Password", ButtonType.OK);
                alert.show();
            } else {

            }

        }


    }*/
    @FXML
    void handleIncen(ActionEvent event) {
        String position = txtPos.getText();
        String query = "SELECT `Incentive` FROM `positions` WHERE `Name`= ?";
        connection = Db.getConn();
        try {
            stat = connection.prepareStatement(query);
            stat.setString(1, position);
            rs = stat.executeQuery();
            if (rs.next()) {
                double incen = rs.getDouble("Incentive");
                txtIncen.setText(String.valueOf(incen));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        double Incen;
        if(cBoxIncen.isSelected()){
            double incen = Double.parseDouble(txtIncen.getText());
            Incen = incen;
            txtIncen.setText(String.valueOf(Incen));
        }
        if(!cBoxIncen.isSelected()){
            txtIncen.clear();
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}





