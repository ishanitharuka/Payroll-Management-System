package com.example.new_payroll.Controller;

import com.example.new_payroll.App;
import com.example.new_payroll.Db;
import com.example.new_payroll.ValidationRules;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    private Connection conn = Db.getConn();
    private PreparedStatement st;
    private ResultSet rs;

    @FXML
    private Button btnLogin;

    @FXML
    private PasswordField pwdPassword;

    @FXML
    private TextField txtUname;

    @FXML
    void loginAdmin() {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection conn = Db.getConn();
        try {
            if (ValidationRules.isEmpty(txtUname.getText()) || ValidationRules.isEmpty(pwdPassword.getText())) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Enter Username and Password", ButtonType.OK);
                alert.show();
            } else {
                st = conn.prepareStatement("SELECT * FROM `admin` WHERE `username` = ? AND `password` = ?");
                st.setString(1, txtUname.getText());
                st.setString(2, pwdPassword.getText());
                rs = st.executeQuery();
                if (rs.next()) {
                    FXMLLoader Loader = new FXMLLoader(App.class.getResource("AdminDashboard.fxml"));
                    Scene scene = new Scene(Loader.load());
                    Stage dashboard = new Stage();
                    dashboard.setTitle("Admin Page");
                    dashboard.setScene(scene);
                    dashboard.show();
                    closeLoginWindow();
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "Login Error", ButtonType.OK);
                    alert.show();
                }


            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }




    private void closeLoginWindow() {
        Stage stage = (Stage) btnLogin.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        btnLogin.setOnAction(actionEvent -> loginAdmin());

    }
}




