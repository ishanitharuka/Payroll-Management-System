package com.example.new_payroll.Model;

public class Position {

    private String Name;
    private float Basic;
    private float EPF;
    private float OT;
    private int Attendance;
    private int Incentive;



    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public float getBasic() {
        return Basic;
    }

    public void setBasic(float basic) {
        this.Basic = basic;
    }

    public float getEPF() {
        return EPF;
    }

    public void setEPF(float EPF) {
        this.EPF = EPF;
    }

    public float getOT() {
        return OT;
    }

    public void setOT(float OT) {
        this.OT = OT;
    }

    public int getAttendance() {
        return Attendance;
    }

    public void setAttendance(int attendance) {
        this.Attendance = attendance;
    }

    public int getIncentive() {
        return Incentive;
    }

    public void setIncentive(int incentive) {
        Incentive = incentive;
    }
}
