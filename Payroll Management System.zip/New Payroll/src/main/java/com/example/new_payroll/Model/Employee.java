package com.example.new_payroll.Model;

public class Employee {
    private int Emp_ID;
    private String First_Name;
    private String Last_Name;
    private String Gender;
    private String Contact_No;
    private String Position;

    public Employee(int emp_ID, String first_Name, String last_Name, String gender, String contact_No, String position) {
        Emp_ID = emp_ID;
        First_Name = first_Name;
        Last_Name = last_Name;
        Gender = gender;
        Contact_No = contact_No;
        Position = position;
    }

    public Employee() {

    }

    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int emp_ID) {
        this.Emp_ID = emp_ID;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        this.First_Name = first_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String last_Name) {
        this.Last_Name = last_Name;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        this.Gender = gender;
    }

    public String getContact_No() {
        return Contact_No;
    }

    public void setContact_No(String contact_No) {
        this.Contact_No = contact_No;
    }

    public String getPosition() {
        return Position;
    }

    public void setPosition(String position) {
        Position = position;
    }
}
