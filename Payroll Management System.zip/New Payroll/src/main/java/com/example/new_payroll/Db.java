package com.example.new_payroll;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
public class Db {
    public static Connection DbConn;
    public static Connection getConn(){
        try

        {
            DbConn = DriverManager.getConnection("jdbc:mysql://localhost/payroll_system", "root", "");
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return DbConn;
    }}

